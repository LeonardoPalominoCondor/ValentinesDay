# valentines
A simple valentine day card made using flipbook.

<a href="https://mrepol742.github.io">
<img src="https://github.com/mrepol742/valentines/blob/master/valentines.gif?raw=true" alt="Valentines Day" />
  </a>

 
  ## HTTP Server
  python3 -m http.server
  
  ## Load the webpage
  http://0.0.0.0:8000/
  
  ## Live
  https://mrepol742.github.io/valentines/
